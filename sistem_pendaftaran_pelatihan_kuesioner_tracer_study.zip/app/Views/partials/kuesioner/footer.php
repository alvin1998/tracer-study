<!-- <a href="http://www.ansonika.com/wilio/#0" class="cd-nav-trigger">Menu<span class="cd-icon"></span></a> -->
        <!-- /menu button -->

        <!-- Modal terms -->
        <div class="modal fade" id="terms-txt" tabindex="-1" role="dialog" aria-labelledby="termsLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="termsLabel">Terms and conditions</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>
                            Lorem ipsum dolor sit amet, in porro albucius qui, in <strong>nec quod novum accumsan</strong>, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt
                            sensibus.
                        </p>
                        <p>
                            Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus. Lorem
                            ipsum dolor sit amet, <strong>in porro albucius qui</strong>, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt
                            sensibus.
                        </p>
                        <p>Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn_1" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

        <!-- COMMON SCRIPTS -->
        <script src="<?= base_url(); ?>/public/assets/wilio/js/jquery-3.5.1.min.js"></script>
        <script src="<?= base_url(); ?>/public/assets/wilio/js/common_scripts.min.js"></script>
        <script src="<?= base_url(); ?>/public/assets/wilio/js/velocity.min.js"></script>
        <script src="<?= base_url(); ?>/public/assets/wilio/js/functions.js"></script>
        <script src="<?= base_url(); ?>/public/assets/toastr/toastr.min.js"></script>
        <script src="<?= base_url(); ?>/public/assets/js/loadingoverlay.min.js"></script>

        <!-- Wizard script -->
        <script src="<?= base_url(); ?>/public/assets/wilio/js/survey_func.js"></script>
    </body>