<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/fonts/icomoon/style.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/jquery-ui.css" />
<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/owl.carousel.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/owl.theme.default.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/owl.theme.default.min.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/jquery.fancybox.min.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/bootstrap-datepicker.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/fonts/flaticon/font/flaticon.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/aos.css" />

<link rel="stylesheet" href="<?= base_url(); ?>/public/assets/css/style.css" />
<link href="<?= base_url(); ?>/public/assets/toastr/toastr.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
	.btn .btn-primary {
		background: #2ecf9f;
	}
</style>