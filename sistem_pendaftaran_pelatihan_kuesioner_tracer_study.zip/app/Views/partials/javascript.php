<script src="<?= base_url(); ?>/public/assets/js/jquery-3.3.1.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery-migrate-3.0.1.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery-ui.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/popper.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery.stellar.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery.countdown.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/bootstrap-datepicker.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery.easing.1.3.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/aos.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery.fancybox.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/jquery.sticky.js"></script>

<script src="<?= base_url(); ?>/public/assets/js/main.js"></script>
<script src="<?= base_url(); ?>/public/assets/toastr/toastr.min.js"></script>
<script src="<?= base_url(); ?>/public/assets/js/loadingoverlay.min.js"></script>
